import './App.css';
import Header from './header';
import BlogList from './BlogList';
import { useEffect } from 'react';

function App() {
  
  return (
    <div className="app-container">
      <Header>
	</Header>
    <main>
      <BlogList />
    </main>
    </div>

  );
}

export default App;
