import './App.css';
import Header from './header';
import BlogList from './BlogList';

function App() {
  return (
    <div className="app-container">
      <Header>
	</Header>
    </div>
  );
}

export default App;
