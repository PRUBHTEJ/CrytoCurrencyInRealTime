import React from 'react';

class BlogList extends React.Component {
    render() {
        return (
            <div>
                <h1>Blog List</h1>
                <p>This is the blog list page.</p>
            </div>
        );
    }
}

export default BlogList;